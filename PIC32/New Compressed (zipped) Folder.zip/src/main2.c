/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#define _SUPPRESS_PLIB_WARNING
//#include <plib_spi1_master.c>

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include <xc.h>
#include <stdint.h>
#include <proc/p32mx470f512h.h>
#include <string.h>
#include <stdio.h>
#define _XTAL_FREQ 1000000

#define MAX_STRING_LENGTH 50 
#define NUM_STRINGS 3

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
char c;

void __delay_us(uint16_t us){
    uint32_t delay_count = _XTAL_FREQ / 4000;
    while (us--){
        uint32_t i;
        for (i = 0; i < delay_count; i++){
            //do nothing
        }
    }
}

unsigned char spi_put_get_byte (unsigned char d)
{
    //send data to slave 
    SPI1BUF = d;
    //wait until SPI transmission complete 
    while (SPI1STATbits.SPITBF);
    return SPI1BUF;
}
/*bool SPI1_Write(const uint8_t *buffer, const size_t size){
    {
        for (size_t i = 0; i<size; i++){
            while (!SPI1STATbits.SPITBE);
            SPI1BUF = buffer[i];
            while (!SPI1STATbits.SPIRBF);
            (void)SPI1BUF;
        }
    }
    return true;
}*/

/*bool SPI1_Read(uint8_t *buffer, const size_t size){
    {
        for (size_t i = 0; i < size; i++){
            while (!SPI1STATbits.SPITBE);
            SPI1BUF = 0x00;
            while (!SPI1STATbits.SPITBF);
            buffer[i] = SPI1BUF;
        }
    }
    return true;
}*/

void UART_SendVoltage(uint16_t voltage)
{
    char buffer[16];
    sprintf(buffer, "%u mV\r\n", voltage);
    UART1_Write(buffer, strlen(buffer));
}

char data;

int main ( void )
{
//    unsigned int adc_value[16];
    
    /* Initialize all modules */
    SYS_Initialize (NULL );
    SPI1_Initialize();
    UART1_Initialize();
    
    /*while (1){
        char buffer[16];

        //convert the unsigned integer to a string using sprintf
        sprintf(buffer, "Hello!\r\n");

        //send the string through UART
        UART1_Write(buffer, strlen(buffer));
        while (UART1_WriteIsBusy());}*/

        //void* recieveData; 
    //size_t rxdata = 2;
    //SPI1_CallbackRegister(SPI1_Receive_ISR);
    //bool read = SPI1_Read(recieveData, rxdata);
    
    //uint8_t tx_buffer[] = {0x01, 0x02};
    //uint8_t rx_buffer[2];
    
    /*//Select the slave device 
    //SS1_SetLow();
    LATBbits.LATB9 = 0;
    //Transmit data over SPI
    SPI1_Write(tx_buffer, sizeof(tx_buffer));
    
    //Receiver data over SPI
    SPI1_Read(rx_buffer, sizeof(rx_buffer));
    
    //Deselect the slave device
    //SS1_SetHigh();
    LATBbits.LATB9 = 1;*/

    while(1)
    {
        
        int i = 0;
        //Set chip1 select low 
        //__delay_ms(0.032);
        //LATBbits.LATB11 = 0;
        
        GPIO_RD9_Toggle();
        __delay_us(8);
        for(i=0;i<8;i++) //array with 16 value
        {
            unsigned int ADC_Value;
            unsigned char cmd = 0x86 | (i << 4);
            unsigned char msb, lsb;
            //Send SPI command
            spi_put_get_byte(cmd);
            //Retrieve SPI Data
            msb = spi_put_get_byte(0x00);
            lsb = spi_put_get_byte(0x00);
            ADC_Value = (msb << 8) | lsb;
            char buffer[32];
            //convert the unsigned integer to a string using sprintf
            sprintf(buffer, "%u:%u/r/n", i, ADC_Value);
            //send the string through UART
            UART1_Write(buffer, strlen(buffer));
            __delay_us(10000);
       
        }
        //Set chip1 select high
        //LATBbits.LATB11 = 1;
        __delay_us(32);
        GPIO_RD9_Toggle();
        __delay_us(8);
        

        GPIO_RF4_Toggle();
        __delay_us(8);
        for(i=8;i<16;i++) //Cell 9 through 16
        {
            unsigned int ADC_Value;
            unsigned char cmd = 0x86 | (i << 4);
            unsigned char msb, lsb;
            //Send SPI command
            spi_put_get_byte(cmd);
            //Retrieve SPI Data
            msb = spi_put_get_byte(0x00);
            lsb = spi_put_get_byte(0x00);
            ADC_Value = (msb << 8) | lsb;
            char buffer[32];
            //convert the unsigned integer to a string using sprintf
            sprintf(buffer, "%u:%u/r/n", i, ADC_Value);
            //send the string through UART
            UART1_Write(buffer, strlen(buffer));
            __delay_us(10000);

        }
        /*//Set chip2 select high
        //LATBbits.LATB15 = 1;
        __delay_us(32);
        GPIO_RF4_Toggle();
        
        //Convert array to string 
        char strADC[32];
        int j;
        for (j = 0; j<16; j++){
            sprintf(strADC+i, "%d", adc_value[i]);
        }
        int f;
        //Send String over UART
        for(f = 0; f<32; f++){
            UART1_Write((void*)strADC[i], sizeof(tx_buffer));
        }*/
        
        //UART_SendVoltage(adc_value);}*/
        //Sends the array of voltages through UART
        //size_t arraySize = sizeof(adc_value);
        
        //create a buffer from the array in bytes
        //uint8_t *buffer = (uint8_t *)adc_value;
        
        //!!!!!!!!!!!!!!!!!!!!!!!UART CODE!!!!!!!!!!!!!!!!!!!!!!!!!!
        //UART1_Write(buffer, arraySize);
        /*while (1){
        char buffer[32];
        //convert the unsigned integer to a string using sprintf
        sprintf(buffer,);
        __delay_us(10000);
       
        //send the string through UART
        UART1_Write(buffer, strlen(buffer));
        while (UART1_WriteIsBusy());}     
        
        
        while(1){
        bool status; 
        char buffer[16];
        
        for(int i = 0; i < 16; i++){
        
        //convert the unsigned integer to a string using sprintf
        sprintf(buffer, "%u:%u\r\n", i, adc_value[i]);
        
        //send the string through UART
        status = UART1_Write(buffer, strlen(buffer));
        while (UART1_WriteIsBusy());
        if (status == false){
            //UART1_Write("ERROR", strlen(buffer));
            printf("ERROR");
        }*/
        }
    }

//    }
    //Sends the array of voltages through UART
    //size_t arraySize = sizeof(adc_value);
        
    //create a buffer from the array in bytes
    //uint8_t *buffer = (uint8_t *)adc_value;
        
    //UART1_Write(buffer, arraySize);
    /*UART_SERIAL_SETUP uartSetup = {
        .parity = UART_PARITY_NONE,
        .stopBits = UART_STOP_1_BIT,
        .baudRate = 9600
    };
    bool success = UART1_SerialSetup(&uartSetup, 96000000UL);
    if (success == true){*/

    /*while(1)
    {
    char buffer[16];

    //convert the unsigned integer to a string using sprintf
    sprintf(buffer, "Hello!\r\n");
        
    //send the string through UART
    UART1_Write(buffer, strlen(buffer));
    while (UART1_WriteIsBusy());
    }*/
    
    

    
    /*for(int i = 0; i < 16; i++){
        bool status; 
        char buffer[16];
        
        //convert the unsigned integer to a string using sprintf
        sprintf(buffer, "%u:%u\r\n", i, adc_value[i]);
        
        //send the string through UART
        status = UART1_Write(buffer, strlen(buffer));
        while (UART1_WriteIsBusy());
        if (status == false){
            //UART1_Write("ERROR", strlen(buffer));
            printf("ERROR");
        }
    }*/
    //}
    //else{
        //printf("ERROR");
    //}
    
    /*char stringArray[NUM_STRINGS][MAX_STRING_LENGTH] = {"Hello", "World", "MPLAB MCC!"};
    bool status;
    //if (success == true){
    for(int i = 0; i < NUM_STRINGS; i++){
        //convert the unsigned integer to a string using sprintf
        
        //send the string through UART
        status = UART1_Write(stringArray[i], strlen(stringArray[i]));
        while (UART1_WriteIsBusy());
        if (status == false){
            //UART1_Write("ERROR", strlen(buffer));
            printf("ERROR");
        }
    }*/
    
    //return ( EXIT_FAILURE );
//}

/*******************************************************************************
 End of File
*/

