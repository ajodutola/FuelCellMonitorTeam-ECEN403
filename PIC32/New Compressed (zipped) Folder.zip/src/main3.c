/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************
#define _SUPPRESS_PLIB_WARNING
//#include <plib_spi1_master.c>

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include <xc.h>
#include <stdint.h>
#include <proc/p32mx470f512h.h>
#include <string.h>
#include <stdio.h>
#define _XTAL_FREQ 1000000

#define MAX_STRING_LENGTH 50 
#define NUM_STRINGS 3

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
char c;

void __delay_us(uint16_t us){
    uint32_t delay_count = _XTAL_FREQ / 4000;
    while (us--){
        uint32_t i;
        for (i = 0; i < delay_count; i++){
            //do nothing
        }
    }
}

unsigned char spi_put_get_byte (unsigned char d)
{
    //send data to slave 
    SPI1BUF = d;
    //wait until SPI transmission complete 
    while (SPI1STATbits.SPITBF);
    return SPI1BUF;
}
/*bool SPI1_Write(const uint8_t *buffer, const size_t size){
    {
        for (size_t i = 0; i<size; i++){
            while (!SPI1STATbits.SPITBE);
            SPI1BUF = buffer[i];
            while (!SPI1STATbits.SPIRBF);
            (void)SPI1BUF;
        }
    }
    return true;
}*/

/*bool SPI1_Read(uint8_t *buffer, const size_t size){
    {
        for (size_t i = 0; i < size; i++){
            while (!SPI1STATbits.SPITBE);
            SPI1BUF = 0x00;
            while (!SPI1STATbits.SPITBF);
            buffer[i] = SPI1BUF;
        }
    }
    return true;
}*/

void UART_SendVoltage(uint16_t voltage)
{
    char buffer[16];
    sprintf(buffer, "%u mV\r\n", voltage);
    UART1_Write(buffer, strlen(buffer));
}

char data;

int main ( void )
{
//    unsigned int adc_value[16];
    
    /* Initialize all modules */
    SYS_Initialize (NULL );
    SPI1_Initialize();
    UART1_Initialize();
    unsigned int cellnum[] = {1,3,5,7,2,4,6,8,9,11,13,15,10,12,14,16};
    
    while(1)
    {
        
        int i = 0;
        //Set chip1 select low 
        //__delay_ms(0.032);
        //LATBbits.LATB11 = 0;
        __delay_us(32);
        GPIO_RD9_Toggle();
        __delay_us(8);
        for(i=0;i<8;i++) //array with 16 value
        {
            unsigned int ADC_Value;
            unsigned char cmd = 0x86 | (i << 4);
            unsigned char msb, lsb;
            //float decimal_value;
            //Send SPI command
            spi_put_get_byte(cmd);
            //Retrieve SPI Data
            msb = spi_put_get_byte(0x00);
            lsb = spi_put_get_byte(0x00);
            ADC_Value = (msb << 8) | lsb;
            //decimal_value = ADC_Value*0.0000625;
            char buffer[32];
            //convert the unsigned integer to a string using sprintf
            sprintf(buffer, "%u:%u/r/n", cellnum[i], ADC_Value);
            //send the string through UART
            UART1_Write(buffer, strlen(buffer));
            __delay_us(1000);
       
        }
        //Set chip1 select high
        //LATBbits.LATB11 = 1;
        __delay_us(32);
        GPIO_RD9_Toggle();
        __delay_us(8);
        //Set chip select 2 low
        __delay_us(32);
        GPIO_RF4_Toggle();
        __delay_us(8);
        for(i=8;i<16;i++) //Cell 9 through 16
        {
            unsigned int ADC_Value;
            unsigned char cmd = 0x86 | (i << 4);
            unsigned char msb, lsb;
            //Send SPI command
            spi_put_get_byte(cmd);
            //Retrieve SPI Data
            msb = spi_put_get_byte(0x00);
            lsb = spi_put_get_byte(0x00);
            ADC_Value = (msb << 8) | lsb;
            char buffer[32];
            //convert the unsigned integer to a string using sprintf
            sprintf(buffer, "%u:%u/r/n", cellnum[i], ADC_Value);
            //send the string through UART
            UART1_Write(buffer, strlen(buffer));
            __delay_us(1000);

        }
         __delay_us(32);
        GPIO_RF4_Toggle();
        __delay_us(8);
        }
    }